NeurOcaml
=========

Processing of in-vivo neural data; spikes, local field potentials, receptive fields