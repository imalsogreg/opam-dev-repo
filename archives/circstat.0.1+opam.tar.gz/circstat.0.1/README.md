ocaml-circular-statistics
=========================

Some stats functions for circular variables